// Animate On Scroll Init
AOS.init({
  duration: 800,
  easing: 'ease-in-out',
  once: true,
});

// Navbar shadow
window.addEventListener("scroll", () => {
  const nav = document.querySelector(".navbar");
  nav.classList.toggle("shadow-sm", window.scrollY > 20);
});
